import csv, sys, time


def get_data(filepath):
    '''Reads the data from the file and returns a list of lists with each inner list containing one row of data.'''

    # Open file for reading.  If unable to open file then exit gracefully!
    try:
        inputFile = open(filepath)  # Read in CSV File (comma separated values) into InputFile object.

    except IOError:  # Exception if cannot read file. Print error message and exit program gracefully!

        print("error found")
